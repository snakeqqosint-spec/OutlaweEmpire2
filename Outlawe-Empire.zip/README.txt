OUTLAWE EMPIRE - готовый клиент (клиент th1nk + наш горизонтальный лаунчер внутри)

ЧТО В РЕПОЗИТОРИИ:
  client.apk              - ЗАГРУЗИ САМ: app-arm64-v8a-release.apk, переименованный в client.apk
  src/                    - исходники нашего лаунчера (Java)
    top/outlawe/launcher/Config.java  - ВСЕ НАСТРОЙКИ: серверы (IP/порт), ссылки, адреса файлов игры
  assets_outlawe/         - картинки лаунчера
  tools/patch_apk.py      - вшивание лаунчера в client.apk
  .github/workflows/build.yml - автосборка

КАК СОБРАТЬ:
  1. Загрузи в репозиторий всё содержимое этой папки + client.apk (в корень).
  2. Вкладка Actions -> Build Outlawe client -> Run workflow.
  3. Когда запуск зелёный, внизу Artifacts -> Outlawe-Empire-APK. Внутри Outlawe-Empire.apk.

УСТАНОВКА:
  Сначала УДАЛИ оригинальный клиент (top.th1nk.samp), у нашей сборки другая подпись.
  Потом установи Outlawe-Empire.apk.
  Каждая новая сборка подписывается новым ключом: перед установкой новой версии удаляй старую.

ВАЖНО:
  Клиент и файлы игры принадлежат их авторам (th1nk, Rockstar). Для публичного запуска
  нужно разрешение автора клиента.
