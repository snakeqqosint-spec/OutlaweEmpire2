package top.outlawe.launcher;

import android.app.Activity;
import android.content.Context;
import android.os.StatFs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Автоустановка файлов игры: скачивает zip, проверяет контрольную сумму SHA-256
 * и распаковывает в папку Android/data/<пакет>/files (оттуда их читает клиент).
 */
public final class Installer {
    private Installer() {}

    public interface Listener {
        void onProgress(int percent, String text);
        void onDone();
        void onError(String message);
    }

    private static final long MIN_FREE_BYTES = 3500L * 1024 * 1024; // ~3,5 ГБ
    private static final String MARKER = ".outlawe_installing";
    private static final Set<String> KNOWN_ROOTS = new HashSet<String>(Arrays.asList(
            "anim", "audio", "data", "fonts", "models", "texdb", "text", "samp"));

    public static File gameDir(Context c) {
        File d = c.getExternalFilesDir(null);
        return d != null ? d : c.getFilesDir();
    }

    /** Игра установлена, если на месте основные папки и нет незавершённой установки */
    public static boolean isInstalled(Context c) {
        File d = gameDir(c);
        if (new File(d, MARKER).exists()) return false;
        return new File(d, "data").isDirectory()
                && new File(d, "models").isDirectory()
                && new File(d, "texdb").isDirectory()
                && new File(d, "anim").isDirectory()
                && new File(d, "audio").isDirectory();
    }

    public static void start(final Activity act, final Listener l) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    install(act, l);
                    act.runOnUiThread(new Runnable() {
                        @Override public void run() { l.onDone(); }
                    });
                } catch (final Exception e) {
                    act.runOnUiThread(new Runnable() {
                        @Override public void run() {
                            l.onError(e.getMessage() != null ? e.getMessage() : e.toString());
                        }
                    });
                }
            }
        }).start();
    }

    private static void progress(final Activity act, final Listener l, final int p, final String text) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() { l.onProgress(p, text); }
        });
    }

    private static void install(Activity act, Listener l) throws Exception {
        File dir = gameDir(act);
        dir.mkdirs();

        long free = new StatFs(dir.getPath()).getAvailableBytes();
        if (free < MIN_FREE_BYTES) {
            throw new Exception("Мало места на телефоне: нужно минимум 3,5 ГБ свободно");
        }

        File tmp = new File(dir, "game_download.tmp");
        boolean ok = false;
        Exception last = null;
        for (String url : Config.GAME_URLS) {
            try {
                download(act, l, url, tmp);
                ok = true;
                break;
            } catch (Exception e) {
                last = e;
                tmp.delete();
            }
        }
        if (!ok) {
            throw new Exception("Не удалось скачать файлы игры: " + (last != null ? last.getMessage() : "нет ссылок"));
        }

        File marker = new File(dir, MARKER);
        marker.createNewFile();
        unzip(act, l, tmp, dir);
        tmp.delete();
        marker.delete();
    }

    private static void download(Activity act, Listener l, String url, File out) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("сервер ответил " + code);
        long total = c.getContentLength() > 0 ? c.getContentLength() : Config.GAME_SIZE;

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        InputStream in = c.getInputStream();
        OutputStream os = new FileOutputStream(out);
        try {
            byte[] buf = new byte[65536];
            long done = 0;
            int last = -1;
            int n;
            while ((n = in.read(buf)) != -1) {
                os.write(buf, 0, n);
                md.update(buf, 0, n);
                done += n;
                int p = (int) (done * 100 / total);
                if (p > 100) p = 100;
                if (p != last) {
                    last = p;
                    progress(act, l, p * 60 / 100, "Скачивание файлов игры: " + p + "%");
                }
            }
        } finally {
            try { os.close(); } catch (Exception ignored) {}
            try { in.close(); } catch (Exception ignored) {}
            c.disconnect();
        }

        StringBuilder hex = new StringBuilder();
        for (byte b : md.digest()) hex.append(String.format("%02x", b));
        if (!hex.toString().equalsIgnoreCase(Config.GAME_SHA256)) {
            throw new IOException("контрольная сумма не совпала (файл повреждён)");
        }
    }

    /** Если весь архив лежит в одной папке-обёртке (не из известных), убираем её */
    private static String commonPrefix(ZipFile zf) {
        String first = null;
        Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            String n = en.nextElement().getName();
            int s = n.indexOf('/');
            if (s < 0) return null;
            String seg = n.substring(0, s);
            if (first == null) first = seg;
            else if (!first.equals(seg)) return null;
        }
        if (first == null || KNOWN_ROOTS.contains(first.toLowerCase())) return null;
        return first + "/";
    }

    private static void unzip(Activity act, Listener l, File zip, File dest) throws Exception {
        ZipFile zf = new ZipFile(zip);
        try {
            String prefix = commonPrefix(zf);
            String base = dest.getCanonicalPath() + File.separator;
            int total = zf.size();
            int i = 0;
            int last = -1;
            byte[] buf = new byte[65536];
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (prefix != null && name.startsWith(prefix)) name = name.substring(prefix.length());
                i++;
                if (name.length() > 0) {
                    File target = new File(dest, name);
                    if (!target.getCanonicalPath().startsWith(base)) {
                        throw new IOException("некорректный архив");
                    }
                    if (e.isDirectory()) {
                        target.mkdirs();
                    } else {
                        File parent = target.getParentFile();
                        if (parent != null) parent.mkdirs();
                        InputStream in = zf.getInputStream(e);
                        OutputStream os = new FileOutputStream(target);
                        try {
                            int n;
                            while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
                        } finally {
                            try { os.close(); } catch (Exception ignored) {}
                            try { in.close(); } catch (Exception ignored) {}
                        }
                    }
                }
                int p = total > 0 ? i * 100 / total : 100;
                if (p != last) {
                    last = p;
                    progress(act, l, 60 + p * 40 / 100, "Установка: " + p + "%");
                }
            }
        } finally {
            zf.close();
        }
    }
}
