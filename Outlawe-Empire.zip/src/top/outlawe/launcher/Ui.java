package top.outlawe.launcher;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;

/** Помощники для построения интерфейса кодом (без XML). */
public final class Ui {
    private Ui() {}

    public static final int PURPLE = 0xFF7B2FF7;
    public static final int PURPLE_DARK = 0xFF3D2A63;

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable rounded(Context c, int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    /** Картинка из assets/outlawe/ */
    public static Bitmap asset(Context c, String name) {
        InputStream in = null;
        try {
            in = c.getAssets().open("outlawe/" + name);
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
        }
    }

    public static ImageView background(Context c, String assetName) {
        ImageView iv = new ImageView(c);
        Bitmap b = asset(c, assetName);
        if (b != null) iv.setImageBitmap(b);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return iv;
    }

    /** Текстовая кнопка со скруглёнными углами */
    @SuppressWarnings("deprecation")
    public static TextView button(Context c, String text, int color, int widthDp, View.OnClickListener l) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundDrawable(rounded(c, color, 10, 0, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, widthDp), dp(c, 44));
        lp.setMargins(dp(c, 4), dp(c, 6), dp(c, 4), dp(c, 6));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    /** Кнопка, прижатая к правому краю: скруглены только левые углы, справа отступа нет */
    @SuppressWarnings("deprecation")
    public static TextView dockedRightButton(Context c, String text, int color, int widthDp, View.OnClickListener l) {
        TextView t = button(c, text, color, widthDp, l);
        float r = dp(c, 12);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadii(new float[]{r, r, 0, 0, 0, 0, r, r});
        t.setBackgroundDrawable(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, widthDp), dp(c, 44));
        lp.setMargins(dp(c, 4), dp(c, 6), 0, dp(c, 6));
        lp.gravity = Gravity.END;
        t.setLayoutParams(lp);
        return t;
    }

    /** Кнопка-картинка: ширина задана, высота по пропорциям картинки */
    public static ImageView imageButton(Context c, String assetName, int widthDp, View.OnClickListener l) {
        ImageView iv = new ImageView(c);
        Bitmap b = asset(c, assetName);
        if (b != null) iv.setImageBitmap(b);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                dp(c, widthDp), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        iv.setLayoutParams(lp);
        iv.setOnClickListener(l);
        return iv;
    }

    @SuppressWarnings("deprecation")
    public static void hideSystemBars(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
