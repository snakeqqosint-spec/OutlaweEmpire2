package top.outlawe.launcher;

/** ВСЕ НАСТРОЙКИ ЛАУНЧЕРА. Меняй здесь. */
public final class Config {
    private Config() {}

    // ---- Ссылки и контакты ----
    public static final String SITE = "https://outlaweempire.gta.how";
    public static final String NEWS = "https://t.me/OutlaweEmpire";
    public static final String TELEGRAM = "https://t.me/NeonXHelper";
    public static final String MAIL = "outlawe_empire@proton.me";
    public static final String DISCORD = "worldsviat";

    // ---- Каталог серверов: ТОЛЬКО эти серверы. Формат: {название, IP, порт, описание} ----
    public static final String[][] SERVERS = {
        {"Purple", "31.58.58.76", "7871", "Основной сервер OutlaweEmpire"},
        // {"Red", "1.2.3.4", "7777", "Второй сервер"},
    };

    // ---- Файлы игры (скачиваются при первом запуске) ----
    // Список адресов: если первый не работает, пробуется следующий.
    // ВАЖНО: это адреса автора клиента (th1nk). Для публичного релиза получи его разрешение
    // или замени на свои ссылки (тогда поменяй GAME_SIZE и GAME_SHA256).
    public static final String[] GAME_URLS = {
        "https://drive.th1nk.top/api/v1/s/de758800-fde8-401a-be33-414550a65bc0/download",
        "https://files.th1nk.top/public/SAMP/Android/lite260905.zip",
        "https://upload.th1nk.top/public/SAMP/Android/lite260905.zip"
    };
    public static final long GAME_SIZE = 587135343L;
    public static final String GAME_SHA256 = "9aeede0622370955734f08178b1858dfd1508c59cc25c52af2e4afa181a00a63";
}
