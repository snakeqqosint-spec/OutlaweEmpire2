package top.th1nk.samp;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import top.outlawe.launcher.Config;
import top.outlawe.launcher.Installer;
import top.outlawe.launcher.Ui;

/**
 * Главный экран OutlaweEmpire. Этот класс ЗАМЕНЯЕТ родной MainActivity клиента
 * (имя класса совпадает намеренно). Он горизонтальный, без чужого каталога серверов,
 * сам скачивает файлы игры и запускает GameActivity клиента на сервер из Config.SERVERS.
 */
public class MainActivity extends Activity {

    private FrameLayout root;
    private EditText nickField;
    private View serversLayer;
    private boolean installing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            // рисуем и под вырезом камеры, чтобы не было чёрной полосы сбоку
            WindowManager.LayoutParams wlp = getWindow().getAttributes();
            wlp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(wlp);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        buildMain();
        setContentView(root);
    }

    // ================= Главный экран =================
    private void buildMain() {
        root.addView(Ui.background(this, "bg_main.jpg"));
        root.addView(buildLogo());
        root.addView(buildNickField());

        // Справа сверху: Telegram, Discord, Почта (квадратные, в ряд)
        LinearLayout topRight = corner(Gravity.TOP | Gravity.END, true);
        topRight.addView(Ui.imageButton(this, "ic_telegram.png", 52, new View.OnClickListener() {
            @Override public void onClick(View v) { openUrl(Config.TELEGRAM); }
        }));
        topRight.addView(Ui.imageButton(this, "ic_discord.png", 52, new View.OnClickListener() {
            @Override public void onClick(View v) { copyText(Config.DISCORD, "Discord: " + Config.DISCORD + " (скопировано)"); }
        }));
        topRight.addView(Ui.imageButton(this, "ic_mail.png", 52, new View.OnClickListener() {
            @Override public void onClick(View v) { openMail(Config.MAIL); }
        }));

        // Слева снизу: «Наш сайт» над «Новости»
        LinearLayout bottomLeft = corner(Gravity.BOTTOM | Gravity.START, false);
        bottomLeft.addView(Ui.imageButton(this, "btn_site.png", 105, new View.OnClickListener() {
            @Override public void onClick(View v) { openUrl(Config.SITE); }
        }));
        bottomLeft.addView(Ui.imageButton(this, "btn_news.png", 85, new View.OnClickListener() {
            @Override public void onClick(View v) { openUrl(Config.NEWS); }
        }));

        // Справа снизу: НАСТРОЙКИ (прижата к правому краю экрана) над ИГРАТЬ (прозрачность 40%)
        LinearLayout bottomRight = corner(Gravity.BOTTOM | Gravity.END, false);
        int pad = Ui.dp(this, 12);
        bottomRight.setPadding(pad, pad, 0, pad);   // справа отступа нет
        bottomRight.addView(Ui.dockedRightButton(this, "НАСТРОЙКИ", Ui.PURPLE_DARK, 150, new View.OnClickListener() {
            @Override public void onClick(View v) { toast("Настройки пока не готовы"); }
        }));
        View play = Ui.button(this, "ИГРАТЬ", 0x997B2FF7, 220, new View.OnClickListener() {
            @Override public void onClick(View v) { onPlay(); }
        });
        ((LinearLayout.LayoutParams) play.getLayoutParams()).rightMargin = Ui.dp(this, 16);
        bottomRight.addView(play);
    }

    // Логотип OutlaweEmpire сверху по центру
    private ImageView buildLogo() {
        ImageView logo = new ImageView(this);
        Bitmap lb = Ui.asset(this, "logo.png");
        if (lb != null) logo.setImageBitmap(lb);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Ui.dp(this, 230), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Ui.dp(this, 6);
        logo.setLayoutParams(lp);
        return logo;
    }

    private LinearLayout corner(int gravity, boolean horizontal) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(horizontal ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        int p = Ui.dp(this, 12);
        l.setPadding(p, p, p, p);
        l.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity));
        root.addView(l);
        return l;
    }

    @SuppressWarnings("deprecation")
    private EditText buildNickField() {
        SharedPreferences prefs = getSharedPreferences("outlawe_launcher", MODE_PRIVATE);
        nickField = new EditText(this);
        nickField.setHint("Nick_Name");
        nickField.setText(prefs.getString("nick", ""));
        nickField.setTextColor(Color.WHITE);
        nickField.setHintTextColor(0x88FFFFFF);
        nickField.setTextSize(14f);
        nickField.setSingleLine(true);
        nickField.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        nickField.setBackgroundDrawable(Ui.rounded(this, 0x55000000, 8, 0, 0));
        nickField.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(20),
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence src, int start, int end, Spanned d, int ds, int de) {
                        for (int i = start; i < end; i++) {
                            char ch = src.charAt(i);
                            boolean ok = ch == '_' || (ch < 128 && Character.isLetterOrDigit(ch));
                            if (!ok) return "";
                        }
                        return null;
                    }
                }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Ui.dp(this, 190), Ui.dp(this, 40), Gravity.TOP | Gravity.START);
        lp.setMargins(Ui.dp(this, 16), Ui.dp(this, 16), 0, 0);
        nickField.setLayoutParams(lp);
        return nickField;
    }

    // ================= ИГРАТЬ =================
    private void onPlay() {
        String nick = nickField.getText().toString().trim();
        if (!nick.matches("[A-Za-z0-9_]{3,20}")) {
            toast("Введите ник: 3-20 символов (латиница, цифры, _)");
            return;
        }
        getSharedPreferences("outlawe_launcher", MODE_PRIVATE).edit().putString("nick", nick).apply();

        if (installing) {
            toast("Идёт установка игры...");
            return;
        }
        if (!Installer.isInstalled(this)) {
            startInstall();
            return;
        }
        showServers();
    }

    // ================= Автоустановка =================
    private void startInstall() {
        installing = true;

        final TextView label = new TextView(this);
        label.setText("Подготовка...");
        label.setTextColor(Color.WHITE);
        label.setTextSize(16f);
        label.setGravity(Gravity.CENTER);

        final ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 14));
        blp.topMargin = Ui.dp(this, 12);
        bar.setLayoutParams(blp);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutParams(new FrameLayout.LayoutParams(Ui.dp(this, 320),
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        box.addView(label);
        box.addView(bar);

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xDD000000);
        overlay.setClickable(true);
        overlay.addView(box);
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Installer.start(this, new Installer.Listener() {
            @Override public void onProgress(int percent, String text) {
                bar.setProgress(percent);
                label.setText(text);
            }
            @Override public void onDone() {
                root.removeView(overlay);
                installing = false;
                showServers();
            }
            @Override public void onError(String message) {
                root.removeView(overlay);
                installing = false;
                toast("Ошибка установки: " + message);
            }
        });
    }

    // ================= Выбор сервера (только свои) =================
    @SuppressWarnings("deprecation")
    private void showServers() {
        if (serversLayer != null) return;

        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Color.BLACK);
        layer.setClickable(true);
        layer.addView(Ui.background(this, "bg_blur.jpg"));

        TextView title = new TextView(this);
        title.setText("ВЫБОР СЕРВЕРА");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tlp.topMargin = Ui.dp(this, 20);
        title.setLayoutParams(tlp);
        layer.addView(title);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(Ui.dp(this, 24), 0, Ui.dp(this, 24), 0);
        row.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        for (int i = 0; i < Config.SERVERS.length; i++) {
            row.addView(serverCard(Config.SERVERS[i]));
        }

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.addView(row);
        scroll.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        layer.addView(scroll);

        LinearLayout back = new LinearLayout(this);
        int p = Ui.dp(this, 12);
        back.setPadding(p, p, p, p);
        back.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START));
        back.addView(Ui.button(this, "НАЗАД", Ui.PURPLE_DARK, 120, new View.OnClickListener() {
            @Override public void onClick(View v) { hideServers(); }
        }));
        layer.addView(back);

        serversLayer = layer;
        root.addView(layer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void hideServers() {
        if (serversLayer != null) {
            root.removeView(serversLayer);
            serversLayer = null;
        }
    }

    @SuppressWarnings("deprecation")
    private View serverCard(final String[] s) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        card.setPadding(p, p, p, p);
        card.setBackgroundDrawable(Ui.rounded(this, 0xCC120A1F, 14, Ui.PURPLE, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(this, 230), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        card.setLayoutParams(lp);

        TextView name = new TextView(this);
        name.setText(s[0]);
        name.setTextColor(Color.WHITE);
        name.setTextSize(20f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(name);

        TextView desc = new TextView(this);
        desc.setText(s[3]);
        desc.setTextColor(0xFFBBBBBB);
        desc.setTextSize(13f);
        desc.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        card.addView(desc);

        card.addView(Ui.button(this, "ИГРАТЬ", Ui.PURPLE, 190, new View.OnClickListener() {
            @Override public void onClick(View v) { launchGame(s); }
        }));
        return card;
    }

    // ================= Запуск игры =================
    private void launchGame(String[] server) {
        String nick = nickField.getText().toString().trim();
        int port;
        try {
            port = Integer.parseInt(server[2]);
        } catch (Exception e) {
            toast("Неверный порт сервера");
            return;
        }
        Intent i = new Intent();
        i.setClassName(getPackageName(), "top.th1nk.samp.feature.game.GameActivity");
        i.putExtra("server_host", server[1]);
        i.putExtra("server_port", port);
        i.putExtra("nickname", nick);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Не удалось запустить игру: " + e.getMessage());
        }
    }

    // ================= Прочее =================
    @Override
    public void onBackPressed() {
        if (serversLayer != null) hideServers();
        else super.onBackPressed();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.hideSystemBars(this);
    }

    @Override
    protected void onPause() {
        getSharedPreferences("outlawe_launcher", MODE_PRIVATE).edit()
                .putString("nick", nickField.getText().toString().trim()).apply();
        super.onPause();
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Не удалось открыть ссылку");
        }
    }

    private void openMail(String address) {
        try {
            startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + address)));
        } catch (Exception e) {
            copyText(address, "Почта скопирована: " + address);
        }
    }

    private void copyText(String text, String message) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("text", text));
        toast(message);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
