#!/usr/bin/env python3
"""Патч APK: кладёт наш classes.dex ПЕРВЫМ (наш MainActivity перекрывает родной),
сдвигает исходные dex на +1, добавляет assets/outlawe/*, убирает старую подпись.
Режим сжатия остальных файлов сохраняется (важно для resources.arsc и .so)."""
import os
import re
import sys
import zipfile

src, our_dex, assets_dir, out = sys.argv[1:5]

zin = zipfile.ZipFile(src)
names = zin.namelist()

def dex_index(n):
    m = re.fullmatch(r'classes(\d*)\.dex', n)
    if not m:
        return None
    return int(m.group(1)) if m.group(1) else 1

def dex_name(i):
    return 'classes.dex' if i == 1 else 'classes%d.dex' % i

sig_re = re.compile(r'META-INF/([^/]+\.(SF|RSA|DSA|EC)|MANIFEST\.MF)$', re.I)

zout = zipfile.ZipFile(out, 'w')
for info in zin.infolist():
    n = info.filename
    if sig_re.match(n):
        continue                      # старая подпись
    data = zin.read(n)
    idx = dex_index(n)
    new = dex_name(idx + 1) if idx else n   # исходные dex сдвигаем: classes.dex -> classes2.dex
    zi = zipfile.ZipInfo(new, date_time=info.date_time)
    zi.compress_type = info.compress_type
    zi.external_attr = info.external_attr
    zout.writestr(zi, data)

with open(our_dex, 'rb') as f:
    zi = zipfile.ZipInfo('classes.dex', date_time=(1981, 1, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    zout.writestr(zi, f.read())

for fn in sorted(os.listdir(assets_dir)):
    with open(os.path.join(assets_dir, fn), 'rb') as f:
        zi = zipfile.ZipInfo('assets/outlawe/' + fn, date_time=(1981, 1, 1, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_STORED
        zout.writestr(zi, f.read())

zout.close()
print('patched ->', out)
