OutlaweLauncher — горизонтальный нативный лаунчер (Kotlin, без внешних библиотек)

СБОРКА (Android Studio на ПК):
1. Распакуй архив, File > Open > папка OutlaweLauncher.
2. Дождись Gradle Sync (нужен интернет, Android Studio сама скачает Gradle).
3. Build > Build APK(s). Готовый APK: app/build/outputs/apk/debug/

ГДЕ ЧТО МЕНЯТЬ:
  Servers.kt       - каталог серверов (ТОЛЬКО эти серверы видны и разрешены)
  Buttons.kt       - все кнопки главного экрана, добавить кнопку = одна строка
  GameLauncher.kt  - запуск клиента (сейчас заглушка)
  Ui.kt            - цвета (PURPLE, GRAY, GREEN)
