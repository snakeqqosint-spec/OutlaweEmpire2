OutlaweLauncher — горизонтальный нативный лаунчер (Kotlin, без внешних библиотек)

ГДЕ ЧТО МЕНЯТЬ (app/src/main/java/com/outlawe/launcher/):
  Servers.kt        - каталог серверов (ТОЛЬКО эти серверы видны и разрешены)
  Buttons.kt        - кнопки главного экрана, добавить кнопку = одна строка
  GameInstaller.kt  - автоустановка игры: впиши GAME_ZIP_URL (ссылка на zip) и GAME_VERSION
  GameLauncher.kt   - запуск клиента (пока заглушка)
  Ui.kt             - цвета

КАРТИНКИ: app/src/main/res/drawable-nodpi/
  bg_main.jpg (фон), bg_blur.jpg (размытый фон выбора сервера), btn_site.png,
  btn_news.png, ic_telegram.png, ic_discord.png, ic_mail.png
Имена файлов только строчными буквами, цифрами и _ (иначе сборка упадёт).
