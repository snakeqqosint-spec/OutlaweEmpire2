package com.outlawe.launcher

import android.app.Activity
import android.widget.Toast

// Запуск игры. СЕЙЧАС ЭТО ЗАГЛУШКА: сюда подключается твой клиент.
object GameLauncher {
    fun launch(activity: Activity, server: Server, nick: String) {
        // Защита: подключаемся только к серверам из каталога
        if (!Servers.isAllowed(server.ip, server.port)) {
            Toast.makeText(activity, "Сервер не из каталога", Toast.LENGTH_SHORT).show()
            return
        }

        // TODO: запуск клиента. Примерно так (имя класса возьми из своего клиента):
        //
        // val intent = android.content.Intent()
        // intent.setClassName(activity.packageName, "com.example.client.GameActivity")
        // intent.putExtra("nick", nick)
        // intent.putExtra("ip", server.ip)
        // intent.putExtra("port", server.port)
        // activity.startActivity(intent)

        Toast.makeText(
            activity,
            "Клиент не подключён: $nick -> ${server.ip}:${server.port}",
            Toast.LENGTH_LONG
        ).show()
    }
}
