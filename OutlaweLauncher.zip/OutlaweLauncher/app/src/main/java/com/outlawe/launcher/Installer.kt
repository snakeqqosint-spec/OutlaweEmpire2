package com.outlawe.launcher

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

// Автоустановка: при запуске лаунчер сравнивает версию на сервере с установленной,
// скачивает zip с файлами игры и распаковывает в папку игры.
//
// ЧТО НУЖНО ЗАЛИТЬ НА ХОСТИНГ (по адресам ниже):
//   version.txt - одна строка с версией, например: 1
//   game.zip    - архив с файлами игры (кэш/клиент)
// Выложил новый game.zip и поменял число в version.txt - у игроков обновится само.
object Installer {
    const val BASE_URL = "https://outlaweempire.gta.how/game"
    const val VERSION_URL = "$BASE_URL/version.txt"
    const val PACK_URL = "$BASE_URL/game.zip"

    // Папка с файлами игры (не требует разрешений): Android/data/<пакет>/files/game
    fun gameDir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "game")

    private fun versionFile(ctx: Context) = File(gameDir(ctx), ".version")

    fun installedVersion(ctx: Context): String? {
        val f = versionFile(ctx)
        return if (f.exists()) f.readText().trim() else null
    }

    // Колбэки вызываются из фонового потока. percent = -1 — процент неизвестен
    fun run(
        ctx: Context,
        onProgress: (text: String, percent: Int) -> Unit,
        onFinish: (success: Boolean, message: String) -> Unit
    ) {
        Thread {
            try {
                onProgress("Проверка обновлений...", -1)
                val remote = try { fetchText(VERSION_URL).trim() } catch (e: Exception) { null }
                val local = installedVersion(ctx)

                if (remote == null) {
                    if (local != null) onFinish(true, "Игра готова")
                    else onFinish(false, "Нет связи с сервером. Проверьте интернет.")
                    return@Thread
                }
                if (local == remote) {
                    onFinish(true, "Игра готова")
                    return@Thread
                }

                // 1) скачиваем во временный файл (старая версия остаётся рабочей, пока не скачали)
                val tmp = File(ctx.cacheDir, "game.zip")
                download(PACK_URL, tmp) { p -> onProgress("Загрузка игры", p) }

                // 2) заменяем старые файлы новыми
                onProgress("Распаковка", 0)
                val dir = gameDir(ctx)
                dir.deleteRecursively()
                dir.mkdirs()
                unzip(tmp, dir) { p -> onProgress("Распаковка", p) }
                tmp.delete()

                versionFile(ctx).writeText(remote)
                onFinish(true, "Игра установлена")
            } catch (e: Exception) {
                onFinish(false, "Ошибка установки: ${e.message}")
            }
        }.start()
    }

    private fun fetchText(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, target: File, onPercent: (Int) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLength
            var done = 0L
            var last = -1
            c.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var n: Int
                    while (input.read(buf).also { n = it } > 0) {
                        output.write(buf, 0, n)
                        done += n
                        val p = if (total > 0) (done * 100 / total).toInt() else -1
                        if (p != last) { last = p; onPercent(p) }
                    }
                }
            }
        } finally {
            c.disconnect()
        }
    }

    private fun unzip(zip: File, dest: File, onPercent: (Int) -> Unit) {
        ZipFile(zip).use { zf ->
            val entries = zf.entries().toList()
            val total = entries.sumOf { it.size.coerceAtLeast(0L) }.coerceAtLeast(1L)
            var done = 0L
            var last = -1
            val destPath = dest.canonicalPath + File.separator
            for (e in entries) {
                val out = File(dest, e.name)
                // защита от выхода за пределы папки (zip-slip)
                if (!out.canonicalPath.startsWith(destPath)) throw IOException("Плохой путь в архиве")
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                zf.getInputStream(e).use { input ->
                    FileOutputStream(out).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var n: Int
                        while (input.read(buf).also { n = it } > 0) {
                            output.write(buf, 0, n)
                            done += n
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onPercent(p) }
                        }
                    }
                }
            }
        }
    }
}
