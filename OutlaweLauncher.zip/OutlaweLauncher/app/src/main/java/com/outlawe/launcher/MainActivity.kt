package com.outlawe.launcher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var nickField: EditText
    private var installing = false
    private val nickRegex = Regex("^[A-Za-z0-9_]{3,20}\$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(backgroundImage(R.drawable.bg_main))
        root.addView(buildNickField())

        // По группе кнопок на каждый угол, где есть кнопки (см. Buttons.kt)
        for (corner in Corner.values()) {
            val items = LauncherButtons.list.filter { it.corner == corner }
            if (items.isEmpty()) continue
            val group = LinearLayout(this).apply {
                orientation = if (corner.horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    corner.gravity
                )
            }
            for (b in items) {
                val view = if (b.iconRes != 0) imageButton(b.iconRes, b.widthDp) { b.onClick(this) }
                else styledButton(b.text, b.color, b.widthDp) { b.onClick(this) }
                group.addView(view)
            }
            root.addView(group)
        }
        setContentView(root)

        // Автоустановка игры при запуске
        if (GameInstaller.needsInstall(this)) startInstall(null)
    }

    // Полупрозрачное поле ника сверху слева (маленькое)
    private fun buildNickField(): EditText {
        val prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        nickField = EditText(this).apply {
            hint = "Nick_Name"
            setText(prefs.getString("nick", ""))
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            textSize = 14f
            setSingleLine()
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = roundedBg(0x55000000, 8)
            // только латиница, цифры и _, до 20 символов
            filters = arrayOf(
                InputFilter.LengthFilter(20),
                InputFilter { src, _, _, _, _, _ -> if (src.all { it.isLetterOrDigit() && it.code < 128 || it == '_' }) null else "" }
            )
            layoutParams = FrameLayout.LayoutParams(dp(190), dp(40), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(16), dp(16), 0, 0)
            }
        }
        return nickField
    }

    override fun onPause() {
        saveNick()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun saveNick() {
        getSharedPreferences("launcher", MODE_PRIVATE).edit()
            .putString("nick", nickField.text.toString().trim()).apply()
    }

    // ---- Автоустановка: окно с прогрессом поверх экрана ----
    private fun startInstall(onDone: (() -> Unit)?) {
        if (installing) return
        installing = true

        val label = TextView(this).apply {
            text = "Подготовка..."
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14)).apply { topMargin = dp(12) }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
            addView(label)
            addView(bar)
        }
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(0xDD000000.toInt())
            isClickable = true   // перехватываем нажатия, пока идёт установка
            addView(box)
        }
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        GameInstaller.install(
            this,
            onProgress = { p, text -> bar.progress = p; label.text = text },
            onDone = {
                root.removeView(overlay)
                installing = false
                onDone?.invoke()
            },
            onError = { msg ->
                root.removeView(overlay)
                installing = false
                toast("Ошибка установки: $msg")
            }
        )
    }

    // ---- Действия для кнопок (вызываются из Buttons.kt) ----

    fun openServers() {
        val nick = nickField.text.toString().trim()
        if (!nickRegex.matches(nick)) {
            toast("Введите ник: 3-20 символов (латиница, цифры, _)")
            return
        }
        saveNick()
        if (installing) {
            toast("Идёт установка игры...")
            return
        }
        if (GameInstaller.needsInstall(this)) {
            startInstall { startActivity(Intent(this, ServersActivity::class.java)) }
            return
        }
        startActivity(Intent(this, ServersActivity::class.java))
    }

    fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    fun openMail(address: String) {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$address")))
        } catch (e: Exception) {
            copyText(address, "Почта скопирована: $address")
        }
    }

    fun copyText(text: String, message: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        toast(message)
    }

    fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
