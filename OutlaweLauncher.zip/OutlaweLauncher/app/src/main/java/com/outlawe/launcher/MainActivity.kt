package com.outlawe.launcher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var nickField: EditText
    private val nickRegex = Regex("^[A-Za-z0-9_]{3,20}\$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        root.addView(buildNickField())

        // По колонке кнопок на каждый угол, где есть кнопки (см. Buttons.kt)
        for (corner in Corner.values()) {
            val items = LauncherButtons.list.filter { it.corner == corner }
            if (items.isEmpty()) continue
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(16), dp(16), dp(16))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    corner.gravity
                )
            }
            for (b in items) {
                column.addView(styledButton(b.text, b.color, b.widthDp) { b.onClick(this) })
            }
            root.addView(column)
        }
        setContentView(root)
    }

    // Полупрозрачное поле ника сверху слева (маленькое)
    private fun buildNickField(): EditText {
        val prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        nickField = EditText(this).apply {
            hint = "Nick_Name"
            setText(prefs.getString("nick", ""))
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            textSize = 14f
            setSingleLine()
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = roundedBg(0x44FFFFFF, 8)
            // только латиница, цифры и _, до 20 символов
            filters = arrayOf(
                InputFilter.LengthFilter(20),
                InputFilter { src, _, _, _, _, _ -> if (src.all { it.isLetterOrDigit() && it.code < 128 || it == '_' }) null else "" }
            )
            layoutParams = FrameLayout.LayoutParams(dp(190), dp(40), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(16), dp(16), 0, 0)
            }
        }
        return nickField
    }

    override fun onPause() {
        saveNick()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun saveNick() {
        getSharedPreferences("launcher", MODE_PRIVATE).edit()
            .putString("nick", nickField.text.toString().trim()).apply()
    }

    // ---- Действия для кнопок (вызываются из Buttons.kt) ----

    fun openServers() {
        val nick = nickField.text.toString().trim()
        if (!nickRegex.matches(nick)) {
            toast("Введите ник: 3-20 символов (латиница, цифры, _)")
            return
        }
        saveNick()
        startActivity(Intent(this, ServersActivity::class.java))
    }

    fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Не удалось открыть ссылку")
        }
    }

    fun openMail(address: String) {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$address")))
        } catch (e: Exception) {
            copyText(address, "Почта скопирована: $address")
        }
    }

    fun copyText(text: String, message: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        toast(message)
    }

    fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
