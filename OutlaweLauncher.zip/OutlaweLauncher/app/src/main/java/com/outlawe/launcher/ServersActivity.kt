package com.outlawe.launcher

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

// Каталог серверов: показывает ТОЛЬКО то, что записано в Servers.list
class ServersActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val nick = getSharedPreferences("launcher", MODE_PRIVATE).getString("nick", "") ?: ""

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        root.addView(TextView(this).apply {
            text = "ВЫБОР СЕРВЕРА"
            setTextColor(PURPLE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = dp(20) }
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, dp(24), 0)
        }
        for (s in Servers.list) row.addView(serverCard(s, nick))

        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        })

        // Кнопка «Назад» слева снизу
        root.addView(LinearLayout(this).apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.START
            )
            addView(styledButton("НАЗАД", GRAY, 120) { finish() })
        })
        setContentView(root)
    }

    private fun serverCard(s: Server, nick: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = roundedBg(0xFF1A1A1A.toInt(), 14, PURPLE, 2)
            layoutParams = LinearLayout.LayoutParams(dp(230), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(8), 0, dp(8), 0)
            }
            addView(TextView(context).apply {
                text = s.name
                setTextColor(Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = s.description
                setTextColor(0xFFAAAAAA.toInt())
                textSize = 13f
                setPadding(0, dp(4), 0, dp(12))
            })
            addView(styledButton("ИГРАТЬ", PURPLE, 198) { GameLauncher.launch(this@ServersActivity, s, nick) })
        }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }
}
