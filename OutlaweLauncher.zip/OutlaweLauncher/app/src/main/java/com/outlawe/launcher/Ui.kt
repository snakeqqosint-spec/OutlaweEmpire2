package com.outlawe.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// Цвета лаунчера
val PURPLE = 0xFF7B2FF7.toInt()
val PURPLE_DARK = 0xFF3D2A63.toInt()
val GRAY = 0xFF2B2B2B.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.roundedBg(color: Int, radiusDp: Int = 10, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

// Текстовая кнопка со скруглёнными углами
fun Context.styledButton(text: String, color: Int, widthDp: Int, onClick: () -> Unit): TextView =
    TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = roundedBg(color)
        layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(44)).apply {
            setMargins(dp(4), dp(6), dp(4), dp(6))
        }
        setOnClickListener { onClick() }
    }

// Кнопка-картинка: ширина задаётся, высота считается по пропорциям картинки
fun Context.imageButton(res: Int, widthDp: Int, onClick: () -> Unit): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        adjustViewBounds = true
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        setOnClickListener { onClick() }
    }

// Фоновая картинка на весь экран
fun Context.backgroundImage(res: Int): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

// Полноэкранный режим без системных панелей
@Suppress("DEPRECATION")
fun Activity.hideSystemBars() {
    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
}
