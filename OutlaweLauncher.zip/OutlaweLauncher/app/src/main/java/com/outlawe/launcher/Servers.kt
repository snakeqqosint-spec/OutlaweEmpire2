package com.outlawe.launcher

data class Server(
    val name: String,        // название на кнопке
    val ip: String,
    val port: Int,
    val description: String  // подпись под названием
)

object Servers {
    // ЕДИНСТВЕННОЕ место, где задаются серверы. Каталог показывает ТОЛЬКО их.
    // Чтобы добавить сервер, допиши строку Server(...) в список.
    val list = listOf(
        Server("Purple", "127.0.0.1", 7777, "Основной сервер OutlaweEmpire")   // IP заглушка, замени на свой
        // Server("Red", "1.2.3.4", 7777, "Второй сервер"),
    )

    // Белый список: клиент должен подключаться только если IP:порт есть в каталоге
    fun isAllowed(ip: String, port: Int): Boolean = list.any { it.ip == ip && it.port == port }
}
