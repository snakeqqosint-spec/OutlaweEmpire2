package com.outlawe.launcher

import android.app.Activity
import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

// Автоустановка файлов игры: скачивает zip и распаковывает в папку игры.
// Запускается сама при старте лаунчера и при нажатии «ИГРАТЬ», если версия на устройстве не совпадает.
object GameInstaller {
    // Поменяй версию, когда выложишь новый архив: игроки докачают обновление сами.
    const val GAME_VERSION = "1"

    // Ссылка на zip с файлами игры. ПУСТО = автоустановка выключена.
    const val GAME_ZIP_URL = ""

    fun gameDir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "game")

    fun needsInstall(ctx: Context): Boolean {
        if (GAME_ZIP_URL.isBlank()) return false
        val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        return prefs.getString("game_version", "") != GAME_VERSION || !gameDir(ctx).exists()
    }

    // Все колбэки вызываются в главном потоке
    fun install(
        activity: Activity,
        onProgress: (Int, String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val zip = File(activity.cacheDir, "game.zip")
                download(GAME_ZIP_URL, zip) { p ->
                    activity.runOnUiThread { onProgress(p * 70 / 100, "Скачивание файлов игры: $p%") }
                }
                val dir = gameDir(activity)
                dir.deleteRecursively()
                dir.mkdirs()
                unzip(zip, dir) { p ->
                    activity.runOnUiThread { onProgress(70 + p * 30 / 100, "Установка: $p%") }
                }
                zip.delete()
                activity.getSharedPreferences("launcher", Context.MODE_PRIVATE)
                    .edit().putString("game_version", GAME_VERSION).apply()
                activity.runOnUiThread { onDone() }
            } catch (e: Exception) {
                activity.runOnUiThread { onError(e.message ?: "неизвестная ошибка") }
            }
        }.start()
    }

    private fun download(url: String, out: File, onPercent: (Int) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        if (c.responseCode != 200) throw Exception("сервер ответил " + c.responseCode)
        val total = c.contentLengthLong
        var last = -1
        c.inputStream.use { input ->
            out.outputStream().use { output ->
                val buf = ByteArray(65536)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            onPercent(p)
                        }
                    }
                }
            }
        }
    }

    private fun unzip(zip: File, dest: File, onPercent: (Int) -> Unit) {
        val destPath = dest.canonicalPath + File.separator
        ZipFile(zip).use { zf ->
            val total = zf.size()
            var i = 0
            var last = -1
            for (e in zf.entries().asSequence()) {
                val target = File(dest, e.name)
                // защита от архивов с путями вида ../
                if (!target.canonicalPath.startsWith(destPath)) throw Exception("некорректный архив")
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    zf.getInputStream(e).use { inp -> target.outputStream().use { inp.copyTo(it) } }
                }
                i++
                val p = if (total > 0) i * 100 / total else 100
                if (p != last) {
                    last = p
                    onPercent(p)
                }
            }
        }
    }
}
