package com.outlawe.launcher

import android.view.Gravity

// Угол экрана, в котором стоит колонка кнопок
enum class Corner(val gravity: Int) {
    TOP_LEFT(Gravity.TOP or Gravity.START),
    TOP_RIGHT(Gravity.TOP or Gravity.END),
    BOTTOM_LEFT(Gravity.BOTTOM or Gravity.START),
    BOTTOM_RIGHT(Gravity.BOTTOM or Gravity.END)
}

class LauncherButton(
    val text: String,
    val corner: Corner,
    val color: Int,
    val widthDp: Int = 160,
    val onClick: (MainActivity) -> Unit
)

// ВСЕ КНОПКИ ГЛАВНОГО ЭКРАНА. Чтобы добавить кнопку — допиши одну строку.
// Порядок строк = порядок сверху вниз внутри угла.
object LauncherButtons {
    private const val SITE = "https://outlaweempire.kal.how"   // замени на свой домен

    val list = listOf(
        // Справа сверху: связь
        LauncherButton("Telegram", Corner.TOP_RIGHT, GRAY, 150) { it.openUrl("https://t.me/NeonXHelper") },
        LauncherButton("Почта", Corner.TOP_RIGHT, GRAY, 150) { it.openMail("outlawe_empire@proton.me") },
        LauncherButton("Discord", Corner.TOP_RIGHT, GRAY, 150) { it.copyText("worldsviat", "Discord: worldsviat (скопировано)") },

        // Слева снизу
        LauncherButton("Наш сайт", Corner.BOTTOM_LEFT, GRAY, 150) { it.openUrl(SITE) },
        LauncherButton("Новости", Corner.BOTTOM_LEFT, GRAY, 150) { it.openUrl(SITE) },

        // Справа снизу
        LauncherButton("НАСТРОЙКИ", Corner.BOTTOM_RIGHT, PURPLE, 220) { it.toast("Настройки пока не готовы") },
        LauncherButton("ИГРАТЬ", Corner.BOTTOM_RIGHT, GREEN, 220) { it.openServers() }
    )
}
