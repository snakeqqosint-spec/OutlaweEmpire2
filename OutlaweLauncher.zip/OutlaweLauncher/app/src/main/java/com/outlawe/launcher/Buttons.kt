package com.outlawe.launcher

import android.view.Gravity

// Угол экрана, в котором стоит группа кнопок. horizontal = кнопки в ряд
enum class Corner(val gravity: Int, val horizontal: Boolean) {
    TOP_LEFT(Gravity.TOP or Gravity.START, false),
    TOP_RIGHT(Gravity.TOP or Gravity.END, true),
    BOTTOM_LEFT(Gravity.BOTTOM or Gravity.START, false),
    BOTTOM_RIGHT(Gravity.BOTTOM or Gravity.END, false)
}

// Кнопка: либо текстовая (text + color), либо картинка (iconRes = R.drawable.xxx)
class LauncherButton(
    val corner: Corner,
    val text: String = "",
    val iconRes: Int = 0,
    val color: Int = GRAY,
    val widthDp: Int = 160,
    val onClick: (MainActivity) -> Unit
)

// ВСЕ КНОПКИ ГЛАВНОГО ЭКРАНА. Чтобы добавить кнопку — допиши одну строку.
// Порядок строк = порядок слева направо (ряд) или сверху вниз (колонка).
object LauncherButtons {
    private const val SITE = "https://outlaweempire.gta.how"
    private const val NEWS = "https://t.me/NeonXHelper"   // замени на ссылку своего ТГ-канала

    val list = listOf(
        // Справа сверху: квадратные кнопки в ряд (Telegram, Discord, Почта)
        LauncherButton(Corner.TOP_RIGHT, iconRes = R.drawable.ic_telegram, widthDp = 52) { it.openUrl("https://t.me/NeonXHelper") },
        LauncherButton(Corner.TOP_RIGHT, iconRes = R.drawable.ic_discord, widthDp = 52) { it.copyText("worldsviat", "Discord: worldsviat (скопировано)") },
        LauncherButton(Corner.TOP_RIGHT, iconRes = R.drawable.ic_mail, widthDp = 52) { it.openMail("outlawe_empire@proton.me") },

        // Слева снизу: «Наш сайт» над «Новости»
        LauncherButton(Corner.BOTTOM_LEFT, iconRes = R.drawable.btn_site, widthDp = 150) { it.openUrl(SITE) },
        LauncherButton(Corner.BOTTOM_LEFT, iconRes = R.drawable.btn_news, widthDp = 85) { it.openUrl(NEWS) },

        // Справа снизу: НАСТРОЙКИ (короче) над ИГРАТЬ
        LauncherButton(Corner.BOTTOM_RIGHT, text = "НАСТРОЙКИ", color = PURPLE_DARK, widthDp = 150) { it.toast("Настройки пока не готовы") },
        LauncherButton(Corner.BOTTOM_RIGHT, text = "ИГРАТЬ", color = PURPLE, widthDp = 220) { it.openServers() }
    )
}
