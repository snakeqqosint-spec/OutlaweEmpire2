plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.outlawe.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.outlawe.launcher"
        minSdk = 21          // работает и на старых 32-битных Android
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // 32- и 64-битные устройства (нужно, когда добавишь свои .so клиента)
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}
// Внешних библиотек нет: только стандартный Android SDK.
